---
description: Tag and push updates to the Composer repository
---

This workflow helps you push the latest framework changes to GitHub and tag a new release for Packagist/Composer.

1. Verify that all changes are committed
2. Check the current version in `composer.json`
// turbo
3. Commit all changes
```powershell
git add .
git commit -m "chore: framework final refinement and branding consistency"
```

4. Push to the main repository
// turbo
```powershell
git push origin main
```

5. Tag the new release (optional but recommended for Composer)
// turbo
```powershell
$version = "v1.1.0" # Update this accordingly
git tag $version
git push origin $version
```

6. Verify the update on [Packagist](https://packagist.org/packages/digitalartist/madeline-framework)
